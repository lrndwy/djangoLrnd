from .middleware import LRNDMiddleware
from .views import validate_view